import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { supabase } from "@/services/supabaseClient";
import PageWrapper from "@/components/layouts/PageWrapper";

export default function DokumenUpload() {
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) {
      alert("Pilih file terlebih dahulu");
      return;
    }

    setLoading(true);

    try {
      // 1️⃣ Upload file ke bucket 'documents'
      const fileName = `${Date.now()}_${file.name}`;
      const { data: fileData, error: fileError } = await supabase.storage
        .from("documents")
        .upload(fileName, file);

      if (fileError) throw fileError;

      // 2️⃣ Ambil public URL file
      const { data: urlData } = supabase.storage
        .from("documents")
        .getPublicUrl(fileName);

      // 3️⃣ Simpan metadata ke tabel documents
      const { error: insertError } = await supabase.from("documents").insert([
        {
          title,
          category,
          description,
          file_url: urlData.publicUrl,
        },
      ]);

      if (insertError) throw insertError;

      navigate("/dokumen");
    } catch (err) {
      console.error("Gagal upload dokumen:", err);
      alert("Upload dokumen gagal ❌");
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageWrapper page="dokumen" title="Upload Dokumen">
      <div className="p-4">
        <form onSubmit={handleUpload} className="space-y-4">
          <div>
            <label className="block text-sm mb-1">Judul Dokumen</label>
            <input
              type="text"
              className="w-full border rounded-xl px-3 py-2"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="block text-sm mb-1">Kategori</label>
            <input
              type="text"
              className="w-full border rounded-xl px-3 py-2"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              required
            />
          </div>

          <div>
            <label className="block text-sm mb-1">Deskripsi</label>
            <textarea
              className="w-full border rounded-xl px-3 py-2"
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-sm mb-1">File</label>
            <input
              type="file"
              accept=".pdf,.doc,.docx"
              onChange={(e) => setFile(e.target.files[0])}
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 text-white py-2 rounded-xl font-medium hover:bg-blue-700 transition"
          >
            {loading ? "Mengunggah..." : "Upload Dokumen"}
          </button>
        </form>

        <Link
          to="/dokumen"
          className="mt-6 inline-block text-blue-600 font-medium hover:underline"
        >
          ← Kembali ke Dokumen
        </Link>
      </div>
    </PageWrapper>
  );
}
